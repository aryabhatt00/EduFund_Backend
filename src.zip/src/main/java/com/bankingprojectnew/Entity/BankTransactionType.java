package com.bankingprojectnew.Entity;


public enum BankTransactionType {
    DEPOSIT, WITHDRAWAL
}

