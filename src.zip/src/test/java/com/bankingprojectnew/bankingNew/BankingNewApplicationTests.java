package com.bankingprojectnew.bankingNew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
