package com.bankingprojectnew.DTO;

public class FindCustomer {

	
	    private long phone;
	    private String question1;
	    private String question2;
	    private String question3;
	    
	    
	

}
